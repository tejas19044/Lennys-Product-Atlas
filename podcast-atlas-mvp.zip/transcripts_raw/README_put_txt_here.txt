Put your raw transcript .txt files here (named as Guest Name.txt).
