export const PROMPT_TEXT = `{{prompt}}

(Replace this prompt in app/lib/prompt.ts with your real prompt.)`;
