"use client";

type Props = {
  vocab: { l1: string[]; l2: string[]; l3: string[]; l4: string[] };
  selected: { l1: Set<string>; l2: Set<string>; l3: Set<string>; l4: Set<string> };
  onToggle: (k: "l1"|"l2"|"l3"|"l4", tag: string) => void;
  onClear: () => void;
  search: string;
  setSearch: (v: string) => void;
};

const levelMeta = {
  l1: { title: "Core", colorVar: "--c1" as const },
  l2: { title: "Topics", colorVar: "--c2" as const },
  l3: { title: "Role", colorVar: "--c3" as const },
  l4: { title: "Strategy", colorVar: "--c4" as const },
};

export default function Sidebar({ vocab, selected, onToggle, onClear, search, setSearch }: Props) {
  return (
    <aside style={{ position: "sticky", top: 24, height: "calc(100vh - 48px)", display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ background: "var(--panel)", padding: 16, border: "1px solid var(--border)", borderRadius: 12 }}>
        <div style={{ marginBottom: 10 }}>
          <div style={{ fontSize: 20, fontWeight: 800 }}>Podcast Atlas</div>
          <div style={{ fontSize: 12, color: "var(--muted)" }}>Decision-routing dashboard</div>
        </div>

        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search episodes..."
          style={{
            width: "100%",
            background: "#00000060",
            border: "1px solid var(--border)",
            color: "#fff",
            padding: 12,
            borderRadius: 10,
            outline: "none",
            fontSize: 13,
            marginTop: 8,
          }}
        />

        <button
          onClick={onClear}
          style={{
            marginTop: 10,
            width: "100%",
            background: "transparent",
            border: "1px solid var(--border)",
            color: "var(--muted)",
            padding: 10,
            borderRadius: 10,
            cursor: "pointer",
            fontSize: 11,
            fontWeight: 800,
            textTransform: "uppercase",
            letterSpacing: "0.05em",
          }}
        >
          Clear All Filters
        </button>
      </div>

      <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10, paddingRight: 6 }}>
        {(["l1","l2","l3","l4"] as const).map((k, idx) => (
          <div key={k} style={{ background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 12, padding: 12, borderLeft: `${idx===3?4:3}px solid var(${levelMeta[k].colorVar})` }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, textTransform: "uppercase", fontWeight: 900, letterSpacing: "0.08em", opacity: 0.85, marginBottom: 10 }}>
              <span>{levelMeta[k].title}</span>
              <span>{vocab[k].length}</span>
            </div>

            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {vocab[k].map(tag => {
                const isSel = selected[k].has(tag);
                const bg = isSel ? `var(${levelMeta[k].colorVar})` : "rgba(255,255,255,0.03)";
                const color = isSel ? "#000" : "var(--muted)";
                return (
                  <button
                    key={tag}
                    onClick={() => onToggle(k, tag)}
                    style={{
                      border: "1px solid transparent",
                      background: bg,
                      color,
                      padding: "4px 10px",
                      borderRadius: 8,
                      fontSize: 11,
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 6,
                    }}
                    title={tag}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </aside>
  );
}
