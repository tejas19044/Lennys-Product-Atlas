"use client";

import { useEffect, useState } from "react";
import type { EpisodeRow } from "../page";

type Props = {
  open: boolean;
  episode: EpisodeRow | null;
  onClose: () => void;
  promptText: string;
};

export default function Drawer({ open, episode, onClose, promptText }: Props) {
  const [transcript, setTranscript] = useState<string>("");

  useEffect(() => {
    if (!open || !episode) return;
    setTranscript("Loading transcript...");

    (async () => {
      if (!episode.transcriptFile) {
        setTranscript("Transcript file not found for this row. Run `npm run prep:data` and ensure transcripts are in transcripts_raw/.");
        return;
      }
      try {
        const res = await fetch(`/transcripts/${encodeURIComponent(episode.transcriptFile)}`, { cache: "no-store" });
        const text = await res.text();
        setTranscript(text || "(Empty transcript file)");
      } catch (e) {
        setTranscript("Failed to load transcript.");
      }
    })();
  }, [open, episode]);

  if (!open || !episode) return null;

  return (
    <>
      <div
        onClick={onClose}
        style={{
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.75)",
          backdropFilter: "blur(4px)",
          zIndex: 100,
        }}
      />
      <div
        style={{
          position: "fixed",
          top: 0,
          right: 0,
          width: 720,
          height: "100vh",
          background: "#11141d",
          borderLeft: "1px solid var(--border)",
          zIndex: 101,
          padding: "56px 36px",
          overflowY: "auto",
          boxShadow: "-10px 0 50px rgba(0,0,0,0.5)",
        }}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          style={{
            position: "absolute",
            top: 18,
            left: 18,
            width: 36,
            height: 36,
            borderRadius: 999,
            border: "1px solid var(--border)",
            background: "transparent",
            color: "#fff",
            cursor: "pointer",
            fontSize: 20,
            display: "grid",
            placeItems: "center",
          }}
        >
          ×
        </button>

        <div style={{ fontSize: 12, fontWeight: 900, color: "var(--c4)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
          {episode.companyName || "Company"}
        </div>
        <div style={{ fontSize: 32, fontWeight: 900, marginBottom: 10 }}>{episode.guest}</div>

        <div style={{ color: "var(--muted)", fontSize: 13, lineHeight: 1.6, marginBottom: 18 }}>
          {episode.companyDescription ? episode.companyDescription : null}
        </div>

        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 14, padding: 16, marginBottom: 18 }}>
          <div style={{ fontSize: 12, fontWeight: 900, marginBottom: 10 }}>
            THIS is where API will be called and it will summarize the podcast for you — but as it’s a project, please download the transcript, upload it on your desktop, and enter this prompt:
          </div>
          <pre style={{ whiteSpace: "pre-wrap", margin: 0, color: "#cbd5e1", fontSize: 13, lineHeight: 1.6 }}>
{promptText}
          </pre>
          <div style={{ marginTop: 12, display: "flex", gap: 10, flexWrap: "wrap" }}>
            {episode.transcriptFile ? (
              <a
                href={`/transcripts/${encodeURIComponent(episode.transcriptFile)}`}
                download
                style={{
                  display: "inline-block",
                  background: "#fff",
                  color: "#000",
                  padding: "10px 12px",
                  borderRadius: 10,
                  fontWeight: 900,
                  fontSize: 12,
                  textTransform: "uppercase",
                  letterSpacing: "0.05em",
                  textDecoration: "none",
                }}
              >
                Download Transcript
              </a>
            ) : null}
          </div>
        </div>

        <div style={{ fontSize: 12, fontWeight: 900, textTransform: "uppercase", letterSpacing: "0.08em", color: "#555", marginBottom: 10, borderBottom: "1px solid var(--border)", paddingBottom: 10 }}>
          Full Transcript
        </div>
        <div style={{ whiteSpace: "pre-wrap", lineHeight: 1.8, color: "#b2bec3", fontSize: 14 }}>
          {transcript}
        </div>
      </div>
    </>
  );
}
