"use client";

import type { EpisodeRow } from "../page";

type Props = {
  rows: EpisodeRow[];
  selected: { l1: Set<string>; l2: Set<string>; l3: Set<string>; l4: Set<string> };
  onOpen: (ep: EpisodeRow) => void;
};

function inline(label: string, tags: string[], sel: Set<string>, clsColor: string) {
  if (!tags.length) return null;
  return (
    <div style={{ fontSize: 11, color: "var(--muted)", display: "flex", gap: 10 }}>
      <strong style={{ fontSize: 9, color: "#3d4659", minWidth: 70, textTransform: "uppercase", paddingTop: 2 }}>{label}</strong>
      <span>
        {tags.map((t, i) => (
          <span key={t} style={{ fontWeight: sel.has(t) ? 800 : 500, color: sel.has(t) ? `var(${clsColor})` : "inherit" }}>
            {t}{i < tags.length - 1 ? ", " : ""}
          </span>
        ))}
      </span>
    </div>
  );
}

export default function ResultsGrid({ rows, selected, onOpen }: Props) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
      {rows.map((ep, idx) => (
        <button
          key={(ep.srNo || "") + ep.guest + idx}
          onClick={() => onOpen(ep)}
          style={{
            textAlign: "left",
            background: "var(--panel)",
            border: "1px solid var(--border)",
            borderRadius: 14,
            padding: 22,
            cursor: "pointer",
            display: "flex",
            flexDirection: "column",
            gap: 14,
            transition: "all 0.2s ease",
          }}
        >
          <div>
            <div style={{ color: "var(--muted)", fontSize: 10, fontWeight: 900, textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 6 }}>
              {ep.companyName || "Company"}
            </div>
            <div style={{ fontSize: 20, fontWeight: 800, color: "#fff" }}>{ep.guest || "Guest"}</div>
          </div>

          {ep.frameworks ? (
            <div style={{ fontSize: 12, color: "var(--c2)", opacity: 0.95, lineHeight: 1.5, fontStyle: "italic" }}>
              <strong style={{ fontSize: 9, color: "#4d5669", textTransform: "uppercase", letterSpacing: "0.05em", marginRight: 8, fontWeight: 900, fontStyle: "normal" }}>
                Frameworks
              </strong>
              {ep.frameworks}
            </div>
          ) : null}

          <div style={{ fontSize: 13.5, color: "#b0bacd", lineHeight: 1.6 }}>
            {ep.ceoSummary || ""}
          </div>

          <div style={{ borderTop: "1px solid rgba(255,255,255,0.05)", paddingTop: 12, display: "flex", flexDirection: "column", gap: 6 }}>
            {inline("Core", ep.level1Tags, selected.l1, "--c1")}
            {inline("Topics", ep.level2Tags, selected.l2, "--c2")}
            {inline("Role", ep.level3Tags, selected.l3, "--c3")}
            {inline("Strategy", ep.level4Tags, selected.l4, "--c4")}
          </div>
        </button>
      ))}
    </div>
  );
}
